from .showresults import amorph_postprocess

amorph_postprocess()
